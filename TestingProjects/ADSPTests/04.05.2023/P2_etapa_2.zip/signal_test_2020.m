N=205;
A=0.95;

f0=770;
f1=1477;
fs=8000;

% 4N -> 820 esantioane 0x7FFF
for i=1:4*N
  x(i)=0x7FFF/32768;
end
% N -> 205 esantioane 0x7FFF
for i=4*N+1:5*N
  x(i)=-1.0;
end
% N - 205 esantioane sin f1
for i=5*N+1:6*N
   x(i)=A*sin(2*pi*i*f1/fs);
end
% N - 205 esantioane sin f0
for i=6*N+1:7*N
   x(i)=A*sin(2*pi*i*f0/fs);
end
% N - 205 esantioane sin f1
for i=7*N+1:8*N
   x(i)=A*sin(2*pi*i*f1/fs);
end
% N - 205 esantioane sin f0
for i=8*N+1:9*N
   x(i)=A*sin(2*pi*i*f0/fs);
end
% 10N - 2050 esantioane de zero
for i=9*N+1:23*N
   x(i)=0;
end
% 5 esantioane suplimentare de zero
for i=23*N+1:23*N+5
   x(i)=0;
end
fis=fopen('sgn_test.dat','wt');
fprintf(fis,'%1.14f\n' ,x); 
fclose(fis);

%scriere intr-un fisier audio
audiowrite("DSP_command.wav", x, fs);

