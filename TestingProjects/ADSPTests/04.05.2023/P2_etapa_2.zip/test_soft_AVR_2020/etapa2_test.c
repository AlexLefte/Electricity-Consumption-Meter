/*
char read_keyboard(void);
void write_LED(char a);    
void write_PF(char a);
char read_PF(void);
void ERR(char i, char j);
void Read(char i, char j);
*/

char Q;             // variabila de stare PS
char output_LED;    // variabila de iesire

char cnt1;                  // contor auxiliar
char CODin;                 // cod de comanda (PF in)
char CODout;                // cod de raspuns (PF out)
char cntP;                  // contor caractere parola
char PASS[4]={0,0,0,0};     // parola introdusa
char PASS_C[4]={1,2,3,4};   // parola corecta
char cp;                    // contor caractere in parola
char passERR;              // flag parola gresita

  cnt1=0;
  CODin=0;
  CODout=0;
  cntP=0;

  Q=0;


void MyApplication(void)
{
switch (Q)
{

case 0:
{
CODin=read_PF();   // citeste cod de comanda de la PF

if(CODin==0 || CODin==8) Q=1;
if(CODin==1) Q=2;
if(CODin==2) Q=3;
if(CODin==3) Q=4;
if(CODin==9) Q=5;
}
break;

case 1:             // comanda "inactiv"
{
CODout=3;
write_PF(CODout);
Q=0;
}
break;
                      // aprinde doar LED k, k=0,1,2 sau 3 dat de la tastatura
case 2:
{
Read(2,21);
}
break;
case 20:
{
ERR(20,2);
}
break;

case 21:
{
    if ( (key==0) || (key==1) || (key==2) || (key==3) )  // determina LED de aprins
        {   
        output_LED = output_LED | (1 << key); // aprins in "1"
        write_LED(output_LED);                // aprinde LED k , k=key=nnn
        CODout = CODout | 0x08; // CODout = 00001xxx
        CODout = CODout & 0xF8; // CODout = 00001000
        CODout = CODout | key;  // CODout = 00001nnn
        write_PF(CODout);                      // scrie cod de raspuns in PF   
        Q=0;
        }
    else     // eroare, toate LED aprinse apoi restaureaza starea lor anterioara
        { 
        write_LED(0xFF); // aprinde LED-uri
        Q=20;
        }
}
break;

case 3:
{
Read(3,31);
}
break;

case 30:
{
ERR(30,3);
}
break;

case 31:
{    
if (key!=-1)
    {
    if ( (key==0) || (key==1) || (key==2) || (key==3) )  // determina LED de aprins
        {   
        output_LED = output_LED & (~(1 << key)); // stins in "0"
        write_LED(output_LED);                // stinge LED k , k=key=nnn
        CODout = CODout | 0x08; // CODout = 00001xxx
        CODout = CODout & 0xF8; // CODout = 00001000
        CODout = CODout | key;  // CODout = 00001nnn
        write_PF(CODout);                      // scrie cod de raspuns in PF   
        Q=0;
        }
    else     // eroare, toate LED aprinse apoi restaureaza starea lor anterioara
        { 
        write_LED(0xFF); // aprinde LED-uri
        Q=30;
        }
    }
}
break;

case 4:
{
Read(4,41);
}
break;

case 40:
{
ERR(40,4);
}
break;

case 41:    
{
    if ( (key==0) || (key==1) || (key==2) || (key==3) )  // determina LED de aprins
        {   
        output_LED = output_LED | (1 << key); // aprins in "1"
        write_LED(output_LED);                // aprinde LED k , k=key=nnn
        Q=42;
        }
    else     // eroare, toate LED aprinse apoi restaureaza starea lor anterioara
        { 
        write_LED(0xFF); // aprinde LED-uri
        Q=40;
        }
}
break;

case 42:
{
        cnt1++;
        if (cnt1==50)
            {
            cnt1=0;
            output_LED = output_LED & (~(1 << key)); // stins in "0"
            write_LED(output_LED);                   // stinge LED k , k=key=nnn  
            Q=43;
            }
}
break;

case 43:
{
        cnt1++;
        if (cnt1==50)
        {  
        output_LED = output_LED | (1 << key); // aprins in "1"
        write_LED(output_LED);                // aprinde LED k , k=key=nnn
        
        CODout = CODout | 0x08; // CODout = 00001xxx
        CODout = CODout & 0xF8; // CODout = 00001000
        CODout = CODout | key;  // CODout = 00001nnn
        write_PF(CODout);                      // scrie cod de raspuns in PF   
        Q=0;
        }
}
break;

case 5:
{
Read(5,51);
}
break;

case 51:
{
PASS[cntP]=key;
Q=52;
}
break;

case 52:
{
Read(53,52);
}
break;

case 53:
{
cntP++;
if (cntP==4) Q=54;
else Q=5;
}
break;

case 54:
{
cntP=0;
passERR=0;
    for (cp=0; cp<4; cp++) 
    {
        if (PASS[cp]!=PASS_C[cp])
        {
        passERR=1;
        break;
        } 
    }  
if (passERR==1) Q=55;
else
    {
    CODout=5;
    write_PF(CODout);
    Q=0;
    }
}
break;

case 55:
{
ERR(55,5);
}
break;

}

}

void ERR(char i, char j)
{
cnt1++;
    if (cnt1==50) 
    { 
    cnt1=0;
    write_LED(0x00);
    write_LED(output_LED); 
    Q=j;
    }
    else
    {
    Q=i;
    }
}

void Read(char i, char j)
{
key=read_keyboard();
if (key==-1) Q=i;
else Q=j;
}